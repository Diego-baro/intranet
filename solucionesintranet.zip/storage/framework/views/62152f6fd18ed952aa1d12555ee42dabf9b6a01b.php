<html>
   <head>
      <meta content="text/html; charset=UTF-8" http-equiv="content-type">
      <style type="text/css">ol.lst-kix_list_1-3 {
	list-style-type: none
}

ol.lst-kix_list_1-4 {
	list-style-type: none
}

.lst-kix_list_2-6>li:before {
	content: "" counter(lst-ctn-kix_list_2-6, decimal) ". "
}

.lst-kix_list_2-7>li:before {
	content: "" counter(lst-ctn-kix_list_2-7, lower-latin) ". "
}

.lst-kix_list_2-7>li {
	counter-increment: lst-ctn-kix_list_2-7
}

ol.lst-kix_list_1-5 {
	list-style-type: none
}

ol.lst-kix_list_1-6 {
	list-style-type: none
}

.lst-kix_list_2-1>li {
	counter-increment: lst-ctn-kix_list_2-1
}

ol.lst-kix_list_1-0 {
	list-style-type: none
}

.lst-kix_list_2-4>li:before {
	content: "" counter(lst-ctn-kix_list_2-4, lower-latin) ". "
}

.lst-kix_list_2-5>li:before {
	content: "" counter(lst-ctn-kix_list_2-5, lower-roman) ". "
}

.lst-kix_list_2-8>li:before {
	content: "" counter(lst-ctn-kix_list_2-8, lower-roman) ". "
}

ol.lst-kix_list_1-1 {
	list-style-type: none
}

ol.lst-kix_list_1-2 {
	list-style-type: none
}

.lst-kix_list_1-1>li {
	counter-increment: lst-ctn-kix_list_1-1
}

ol.lst-kix_list_2-6.start {
	counter-reset: lst-ctn-kix_list_2-6 0
}

.lst-kix_list_3-0>li:before {
	content: "\0025cf  "
}

.lst-kix_list_3-1>li:before {
	content: "o  "
}

.lst-kix_list_3-2>li:before {
	content: "\0025aa  "
}

ul.lst-kix_list_3-7 {
	list-style-type: none
}

ul.lst-kix_list_3-8 {
	list-style-type: none
}

ol.lst-kix_list_1-8.start {
	counter-reset: lst-ctn-kix_list_1-8 0
}

ol.lst-kix_list_2-3.start {
	counter-reset: lst-ctn-kix_list_2-3 0
}

ul.lst-kix_list_3-1 {
	list-style-type: none
}

.lst-kix_list_3-5>li:before {
	content: "\0025aa  "
}

ul.lst-kix_list_3-2 {
	list-style-type: none
}

.lst-kix_list_3-4>li:before {
	content: "o  "
}

ul.lst-kix_list_3-0 {
	list-style-type: none
}

ol.lst-kix_list_1-5.start {
	counter-reset: lst-ctn-kix_list_1-5 0
}

ol.lst-kix_list_1-7 {
	list-style-type: none
}

.lst-kix_list_3-3>li:before {
	content: "\0025cf  "
}

ul.lst-kix_list_3-5 {
	list-style-type: none
}

.lst-kix_list_1-7>li {
	counter-increment: lst-ctn-kix_list_1-7
}

ol.lst-kix_list_1-8 {
	list-style-type: none
}

ul.lst-kix_list_3-6 {
	list-style-type: none
}

ul.lst-kix_list_3-3 {
	list-style-type: none
}

ul.lst-kix_list_3-4 {
	list-style-type: none
}

ol.lst-kix_list_2-5.start {
	counter-reset: lst-ctn-kix_list_2-5 0
}

.lst-kix_list_3-8>li:before {
	content: "\0025aa  "
}

.lst-kix_list_2-0>li {
	counter-increment: lst-ctn-kix_list_2-0
}

.lst-kix_list_2-3>li {
	counter-increment: lst-ctn-kix_list_2-3
}

.lst-kix_list_2-6>li {
	counter-increment: lst-ctn-kix_list_2-6
}

.lst-kix_list_3-6>li:before {
	content: "\0025cf  "
}

.lst-kix_list_3-7>li:before {
	content: "o  "
}

ol.lst-kix_list_1-7.start {
	counter-reset: lst-ctn-kix_list_1-7 0
}

.lst-kix_list_1-2>li {
	counter-increment: lst-ctn-kix_list_1-2
}

ol.lst-kix_list_2-2.start {
	counter-reset: lst-ctn-kix_list_2-2 0
}

.lst-kix_list_1-5>li {
	counter-increment: lst-ctn-kix_list_1-5
}

.lst-kix_list_1-8>li {
	counter-increment: lst-ctn-kix_list_1-8
}

ol.lst-kix_list_1-4.start {
	counter-reset: lst-ctn-kix_list_1-4 0
}

ol.lst-kix_list_1-1.start {
	counter-reset: lst-ctn-kix_list_1-1 0
}

ol.lst-kix_list_2-2 {
	list-style-type: none
}

ol.lst-kix_list_2-3 {
	list-style-type: none
}

ol.lst-kix_list_2-4 {
	list-style-type: none
}

ol.lst-kix_list_2-5 {
	list-style-type: none
}

.lst-kix_list_1-4>li {
	counter-increment: lst-ctn-kix_list_1-4
}

ol.lst-kix_list_2-0 {
	list-style-type: none
}

.lst-kix_list_2-4>li {
	counter-increment: lst-ctn-kix_list_2-4
}

ol.lst-kix_list_1-6.start {
	counter-reset: lst-ctn-kix_list_1-6 0
}

ol.lst-kix_list_2-1 {
	list-style-type: none
}

ol.lst-kix_list_1-3.start {
	counter-reset: lst-ctn-kix_list_1-3 0
}

ol.lst-kix_list_2-8.start {
	counter-reset: lst-ctn-kix_list_2-8 0
}

ol.lst-kix_list_1-2.start {
	counter-reset: lst-ctn-kix_list_1-2 0
}

.lst-kix_list_1-0>li:before {
	content: "" counter(lst-ctn-kix_list_1-0, decimal) ". "
}

ol.lst-kix_list_2-6 {
	list-style-type: none
}

.lst-kix_list_1-1>li:before {
	content: "" counter(lst-ctn-kix_list_1-1, lower-latin) ". "
}

.lst-kix_list_1-2>li:before {
	content: "" counter(lst-ctn-kix_list_1-2, lower-roman) ". "
}

ol.lst-kix_list_2-0.start {
	counter-reset: lst-ctn-kix_list_2-0 0
}

ol.lst-kix_list_2-7 {
	list-style-type: none
}

ol.lst-kix_list_2-8 {
	list-style-type: none
}

.lst-kix_list_1-3>li:before {
	content: "" counter(lst-ctn-kix_list_1-3, decimal) ". "
}

.lst-kix_list_1-4>li:before {
	content: "" counter(lst-ctn-kix_list_1-4, lower-latin) ". "
}

ol.lst-kix_list_1-0.start {
	counter-reset: lst-ctn-kix_list_1-0 0
}

.lst-kix_list_1-0>li {
	counter-increment: lst-ctn-kix_list_1-0
}

.lst-kix_list_1-6>li {
	counter-increment: lst-ctn-kix_list_1-6
}

.lst-kix_list_1-7>li:before {
	content: "" counter(lst-ctn-kix_list_1-7, lower-latin) ". "
}

ol.lst-kix_list_2-7.start {
	counter-reset: lst-ctn-kix_list_2-7 0
}

.lst-kix_list_1-3>li {
	counter-increment: lst-ctn-kix_list_1-3
}

.lst-kix_list_1-5>li:before {
	content: "" counter(lst-ctn-kix_list_1-5, lower-roman) ". "
}

.lst-kix_list_1-6>li:before {
	content: "" counter(lst-ctn-kix_list_1-6, decimal) ". "
}

.lst-kix_list_2-0>li:before {
	content: "" counter(lst-ctn-kix_list_2-0, decimal) ". "
}

.lst-kix_list_2-1>li:before {
	content: "" counter(lst-ctn-kix_list_2-1, lower-latin) ". "
}

ol.lst-kix_list_2-1.start {
	counter-reset: lst-ctn-kix_list_2-1 0
}

.lst-kix_list_2-5>li {
	counter-increment: lst-ctn-kix_list_2-5
}

.lst-kix_list_2-8>li {
	counter-increment: lst-ctn-kix_list_2-8
}

.lst-kix_list_1-8>li:before {
	content: "" counter(lst-ctn-kix_list_1-8, lower-roman) ". "
}

.lst-kix_list_2-2>li:before {
	content: "" counter(lst-ctn-kix_list_2-2, lower-roman) ". "
}

.lst-kix_list_2-3>li:before {
	content: "" counter(lst-ctn-kix_list_2-3, decimal) ". "
}

.lst-kix_list_2-2>li {
	counter-increment: lst-ctn-kix_list_2-2
}

ol.lst-kix_list_2-4.start {
	counter-reset: lst-ctn-kix_list_2-4 0
}

ol {
	margin: 0;
	padding: 0
}

table td,
table th {
	padding: 0
}

.c13 {
	-webkit-text-decoration-skip: none;
	color: #000000;
	font-weight: 400;
	text-decoration: underline;
	vertical-align: baseline;
	text-decoration-skip-ink: none;
	font-size: 11pt;
	font-family: "Century Gothic";
	font-style: normal
}

.c0 {
	padding-top: 0pt;
	padding-bottom: 0pt;
	line-height: 1.0;
	page-break-after: avoid;
	orphans: 2;
	widows: 2;
	text-align: justify;
	height: 12pt
}

.c3 {
	padding-top: 0pt;
	padding-bottom: 0pt;
	line-height: 1.0;
	page-break-after: avoid;
	orphans: 2;
	widows: 2;
	text-align: justify
}

.c9 {
	color: #000000;
	font-weight: 700;
	text-decoration: none;
	vertical-align: baseline;
	font-size: 12pt;
	font-family: "Century Gothic";
	font-style: italic
}

.c14 {
	padding-top: 0pt;
	padding-bottom: 8pt;
	line-height: 1.0791666666666666;
	orphans: 2;
	widows: 2;
	text-align: left;
	height: 11pt
}

.c4 {
	padding-top: 0pt;
	padding-bottom: 0pt;
	line-height: 1.0;
	page-break-after: avoid;
	orphans: 2;
	widows: 2;
	text-align: center
}

.c7 {
	color: #000000;
	font-weight: 700;
	text-decoration: none;
	vertical-align: baseline;
	font-size: 12pt;
	font-family: "Century Gothic";
	font-style: normal
}

.c1 {
	color: #000000;
	font-weight: 400;
	text-decoration: none;
	vertical-align: baseline;
	font-size: 12pt;
	font-family: "Century Gothic";
	font-style: normal
}

.c11 {
	color: #000000;
	font-weight: 400;
	text-decoration: none;
	vertical-align: baseline;
	font-size: 11pt;
	font-family: "Century Gothic";
	font-style: italic
}

.c17 {
	color: #000000;
	font-weight: 400;
	text-decoration: none;
	vertical-align: baseline;
	font-size: 20pt;
	font-family: "Calibri";
	font-style: normal
}

.c6 {
	color: #000000;
	font-weight: 700;
	text-decoration: none;
	vertical-align: baseline;
	font-size: 11pt;
	font-family: "Century Gothic";
	font-style: normal
}

.c16 {
	color: #000000;
	font-weight: 700;
	text-decoration: none;
	vertical-align: baseline;
	font-size: 12pt;
	font-family: "Arial";
	font-style: normal
}

.c8 {
	color: #000000;
	font-weight: 400;
	text-decoration: none;
	vertical-align: baseline;
	font-size: 11pt;
	font-family: "Calibri";
	font-style: normal
}

.c2 {
	color: #000000;
	font-weight: 400;
	text-decoration: none;
	vertical-align: baseline;
	font-size: 11pt;
	font-family: "Century Gothic";
	font-style: normal
}

.c15 {
	padding-top: 0pt;
	padding-bottom: 0pt;
	line-height: 1.0;
	orphans: 2;
	widows: 2;
	text-align: center;
}

.c12 {
	padding-top: 0pt;
	padding-bottom: 0pt;
	line-height: 1.0;
	orphans: 2;
	widows: 2;
	text-align: center;
}

.c5 {

	max-width: 441.9pt;
	padding: 0.8pt 65pt 70.8pt 65pt
}

.c10 {
	height: 12pt
}

.title {
	padding-top: 24pt;
	color: #000000;
	font-weight: 700;
	font-size: 36pt;
	padding-bottom: 6pt;
	font-family: "Calibri";
	line-height: 1.0791666666666666;
	page-break-after: avoid;
	orphans: 2;
	widows: 2;
	text-align: left
}

.subtitle {
	padding-top: 18pt;
	color: #666666;
	font-size: 24pt;
	padding-bottom: 4pt;
	font-family: "Georgia";
	line-height: 1.0791666666666666;
	page-break-after: avoid;
	font-style: italic;
	orphans: 2;
	widows: 2;
	text-align: left
}

li {
	color: #000000;
	font-size: 11pt;
	font-family: "Calibri"
}

p {
	margin: 0;
	color: #000000;
	font-size: 11pt;
	font-family: "Calibri"
}

h1 {
	padding-top: 24pt;
	color: #000000;
	font-weight: 700;
	font-size: 24pt;
	padding-bottom: 6pt;
	font-family: "Calibri";
	line-height: 1.0791666666666666;
	page-break-after: avoid;
	orphans: 2;
	widows: 2;
	text-align: left
}

h2 {
	padding-top: 18pt;
	color: #000000;
	font-weight: 700;
	font-size: 18pt;
	padding-bottom: 4pt;
	font-family: "Calibri";
	line-height: 1.0791666666666666;
	page-break-after: avoid;
	orphans: 2;
	widows: 2;
	text-align: left
}

h3 {
	padding-top: 14pt;
	color: #000000;
	font-weight: 700;
	font-size: 14pt;
	padding-bottom: 4pt;
	font-family: "Calibri";
	line-height: 1.0791666666666666;
	page-break-after: avoid;
	orphans: 2;
	widows: 2;
	text-align: left
}

h4 {
	padding-top: 0pt;
	color: #5f5f5f;
	font-weight: 700;
	font-size: 12pt;
	padding-bottom: 0pt;
	font-family: "Tahoma";
	line-height: 1.0;
	page-break-after: avoid;
	orphans: 2;
	widows: 2;
	text-align: justify
}

h5 {
	padding-top: 11pt;
	color: #000000;
	font-weight: 700;
	font-size: 11pt;
	padding-bottom: 2pt;
	font-family: "Calibri";
	line-height: 1.0791666666666666;
	page-break-after: avoid;
	orphans: 2;
	widows: 2;
	text-align: left
}

h6 {
	padding-top: 10pt;
	color: #000000;
	font-weight: 700;
	font-size: 10pt;
	padding-bottom: 2pt;
	font-family: "Calibri";
	line-height: 1.0791666666666666;
	page-break-after: avoid;
	orphans: 2;
	widows: 2;
	text-align: left
}
</style> </head>
  <body class="c5">
     <div>
        <p class="c15"><img src="<?php echo e(asset('img/logo_certificado.png')); ?>" alt="100%"  width="100%"></p>
     </div>
     <p class="c14"><span class="c8"></span></p>
     <h4 class="c4"><span class="c7">LA COORDINACION ADMINISTRATIVA</span></h4>
     <h4 class="c4"><span class="c7">SELECCIONAMOS Y APOYAMOS PERSONAL TEMPORAL S.A.S.</span></h4>
     <h4 class="c4"><span class="c7">NIT: 900.711.126-5</span></h4>
     <p class="c14"><span class="c8"></span></p>
     <h4 class="c4"><span class="c9">Certifica:</span></h4>
     <h4 class="c0"></h4>
     <h4 class="c3" id="h.gjdgxs"><span class="c1">Que <?php echo e($user[0]->Nombre); ?> <?php echo e($user[0]->SegundoApellido); ?> <?php echo e($user[0]->SegundoNombre); ?> <?php echo e($user[0]->PrimerApellido); ?>  &nbsp;Identificado con c&eacute;dula de ciudadan&iacute;a No. <?php echo e($user[0]->cedula); ?> labora con nosotros como trabajador en misi&oacute;n de la empresa <?php echo e($user[0]->Empresa); ?> desempe&ntilde;ando el cargo de <?php echo e($user[0]->Cargo); ?>, devengando un salario de <?php echo e(number_format($user[0]->salario, 2)); ?> vigente m&aacute;s todas las prestaciones sociales desde el d&iacute;a 2 de febrero de 2019 hasta la fecha con un contrato por <?php echo e($user[0]->Tcontrato); ?>.</span></h4>
     <h4 class="c3"><span class="c1">Tiempo durante el cual se caracteriz&oacute; por ser una persona responsable, honesta y cumplidora de su deber.</span></h4>
     <h4 class="c3"><span class="c1">Se expide a solicitud el d&iacute;a cinco (05) del mes de agosto de 2019.</span></h4>
     <h4 class="c0"><span class="c1"></span></h4>
     <h4 class="c3"><span class="c1">Cordialmente,</span></h4>
     <h4 class="c3"><span style="overflow: hidden; display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 237.24px; height: 100px;"><img alt="" src="<?php echo e(asset('img/firmaboss1.jpg')); ?>" style="width: 70%; height: 70%;"></span></h4>
     <h4 class="c3"><span class="c6">HELENA BEATRIZ FLORIAN L&Oacute;PEZ</span></h4>
     <h4 class="c3"><span class="c11">Dpto. de Recursos Humanos</span></h4>
     <p class="c14"><span class="c8"></span></p>

     <div>
        <p class="c12"><span style="overflow: hidden; display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 200.38px; height: 32.89px;"><img alt="" src="<?php echo e(asset('img/imagepagina.png')); ?>" style="width: 200.38px; height: 32.89px;" title=""></span></p>
     </div>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\solucionesintranet\resources\views/pdf/certificado.blade.php ENDPATH**/ ?>