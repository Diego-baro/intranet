<?php $__env->startSection('content'); ?>
<?php if(Session::has('Mensaje')): ?><?php echo e(Session::get('Mensaje')); ?>

<?php endif; ?>
<div class="row">
   <div class="col-xl-12 col-lg-12">
      <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
         <h6 class="m-0 font-weight-bold text-primary">Empresas</h6>
         <a href="<?php echo e(url('empresa/create')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Agregar Empresa</a>
      </div>
      <div class="container-fluid">
         <div class="card-body" style="padding-left: 0px; padding-right: 0px;">
            <div>
               <table class="table" id="" width="100%" cellspacing="0">
                  <thead class="center-text">
                     <tr>
                        <th>Id</th>
                        <th>Nombre Empresa</th>
                        <th>Direccion</th>
                        <th>Rut</th>
                        <th>Nombre Contacto</th>
                        <th>Telefono</th>
                        <th>Acciones</th>
                     </tr>
                  </thead>
                  <tbody class="center-text">
                     <?php $__currentLoopData = $empresa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($empresas->NombreEmpresa); ?></td>
                        <td><?php echo e($empresas->Direccion); ?></td>
                        <td><?php echo e($empresas->Rut); ?></td>
                        <td><?php echo e($empresas->NombreContacto); ?></td>
                        <td><?php echo e($empresas->Telefono); ?></td>
                        <td>
                           <form class="<?php echo e(url('/empresa/'.$empresas->id)); ?>"  method="post">
                              <?php echo e(csrf_field()); ?>

                              <?php echo e(method_field('DELETE')); ?>

                              <a href="<?php echo e(url('/empresa/'.$empresas->id.'/edit')); ?>" class="btn btn-success btn-icon-split" data-toggle="tooltip" data-placement="top" title="Editar"><i class="fas fa-edit"></i></a>
                              <button type="submit" onclick="return confirm('Borrar?');" class="btn btn-danger btn-icon-split" data-toggle="tooltip" data-placement="top" title="Eliminar"><i class="fas fa-trash-alt"></i></button>
                           </form>
                        </td>
                     </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
               </table>
            </div>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\solucionesintranet\resources\views/empresa/index.blade.php ENDPATH**/ ?>