<?php $__env->startSection('content'); ?>
<div class="jumbotron">
  <h1 class="display-4">Hola, <?php echo e(Auth::user()->name); ?></h1>
  <p class="lead">Benvenido de nuevo</p>
  <hr class="my-4">
  <p>Puedes usar este espacio para descargar tu cerificado laboral y comprobantes de pago.</p>
  <p class="lead">
    <?php if(Auth::user()->id == 1 OR Auth::user()->id == 2): ?>
    <a class="btn btn-primary btn-lg" href="<?php echo e(url('/empleados/')); ?>" role="button">Empleados</a>
    <?php else: ?>
  <a class="btn btn-primary btn-lg" href="<?php echo e(url('/empleados/'.Auth::user()->id.'/edit')); ?>" role="button">Mi perfil</a>
  <?php endif; ?>
  </p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\solucionesintranet\resources\views/intro/index.blade.php ENDPATH**/ ?>