<?php $__env->startSection('content'); ?>
<?php if(Session::has('Mensaje')): ?><?php echo e(Session::get('Mensaje')); ?>

<?php endif; ?>
<div class="row">
   <div class="col-xl-12 col-lg-12">
      <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
         <h6 class="m-0 font-weight-bold text-primary">Empleados</h6>
         <a href="<?php echo e(url('empleados/create')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Agregar Empleado</a>
      </div>
      <div class="container-fluid">
         <div class="card-body" style="padding-left: 0px; padding-right: 0px;">
            <div>
               <table class="table" id="" width="100%" cellspacing="0">
                  <thead class="center-text">
                     <tr>
                        <th>id</th>
                        <th>Foto</th>
                        <th>Nombres</th>
                        <th>Apellidos</th>
                        <th>Correo</th>
                        <th>Empresa</th>
                        <th>Acciones</th>
                     </tr>
                  </thead>
                  <tbody class="center-text">
                     <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr>
                        <td><?php echo e($empleado->id); ?></td>
                        <td style="align:center;"><img src="<?php echo e(asset('storage').'/'.$empleado->Foto); ?>" alt="120"  width="120"></td>
                        <td><?php echo e($empleado->Nombre); ?> <?php echo e($empleado->SegundoNombre); ?></td>
                        <td><?php echo e($empleado->PrimerApellido); ?> <?php echo e($empleado->SegundoApellido); ?></td>
                        <td><?php echo e($empleado->Correo); ?></td>
                        <td><?php echo e($empleado->Empresa); ?></td>
                        <td>
                           <form class="" action="<?php echo e(url('/empleados/'.$empleado->id)); ?>" method="post">
                              <?php echo e(csrf_field()); ?>

                              <?php echo e(method_field('DELETE')); ?>

                              <a href="<?php echo e(url('/empleados/'.$empleado->id.'/edit')); ?>" class="btn btn-success" data-toggle="tooltip" data-placement="top" title="Editar"><i class="fas fa-edit"></i></a>
                              <button type="submit" onclick="return confirm('Borrar?');" class="btn btn-danger" data-toggle="tooltip" data-placement="top" title="Eliminar"><i class="fas fa-trash-alt"></i></button>
                           </form>
                        </td>
                     </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
               </table>
                 <?php echo e($empleados->links()); ?>

            </div>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\solucionesintranet\resources\views/empleados/index.blade.php ENDPATH**/ ?>