
<div class="row">
    <?php if(isset($empleado->Foto)): ?>
    <div class="col-md-4 order-md-2 mb-4">

        <h4 class="d-flex justify-content-between align-items-center mb-3">
      <span class="text-muted"><?php echo e($empleado->Nombre); ?> <?php echo e($empleado->SegundoNombre); ?></span>
      <span class="badge badge-secondary badge-pill"></span>
    </h4>
        <ul class="list-group mb-3" style=" text-align: center;">
            <li class="list-group-item d-flex justify-content-between lh-condensed">
                <img class="card-img-top" src="<?php echo e(asset('storage').'/'.$empleado->Foto); ?>" alt="Card image" style="width:100%">
            </li>
            <li class="list-group-item d-flex justify-content-between lh-condensed">



            </li>
            <li class="list-group-item d-flex justify-content-between lh-condensed">
                <small class="text-muted">Descargar Comprobante de pago</small>
                <a href="<?php echo e(route('users.pdf', [ $empleado->id ])); ?>" class="btn btn-info"><i class="fas fa-file-download"></i></a>
            </li>
            <li class="list-group-item d-flex justify-content-between bg-light">
               <small class="text-muted">Descargar certificado laboral</small>
               <a href="<?php echo e(route('certificado.pdf', [ $empleado->id ])); ?>" class="btn btn-info"><i class="fas fa-file-download"></i></a>
            </li>

        </ul>
    </div>
    <?php endif; ?>
    <div class="col-md-8 order-md-1">

        <form class="needs-validation" novalidate>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="NumeroId" class="m-0 font-weight-bold text-primary"><?php echo e('Cedula'); ?></label>
                    <input type="text" name="NumeroId" id="NumeroId" class="form-control form-control-user" value="<?php echo e(isset($empleado->NumeroId)?$empleado->NumeroId:''); ?>" placeholder="[NumeroId]" required>

                    <div class="invalid-feedback">
                        Valid first name is required.
                    </div>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="Nombre" class="m-0 font-weight-bold text-primary"><?php echo e('Nombre'); ?></label>
                    <input type="text" name="Nombre" id="Nombre" class="form-control form-control-user" value="<?php echo e(isset($empleado->Nombre)?$empleado->Nombre:''); ?>" placeholder="[PRIMER NOMBRE]" required>

                    <div class="invalid-feedback">
                        Valid last name is required.
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="SegundoNombre" class="m-0 font-weight-bold text-primary"><?php echo e('Segundo Nombre'); ?></label>
                    <input type="text" name="SegundoNombre" id="SegundoNombre" class="form-control form-control-user" value="<?php echo e(isset($empleado->SegundoNombre)?$empleado->SegundoNombre:''); ?>" placeholder="[SEGUNDO NOMBRE]">
                    <div class="invalid-feedback">
                        Valid first name is required.
                    </div>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="PrimerApellido" class="m-0 font-weight-bold text-primary"><?php echo e('Primer Apellido'); ?></label>
                    <input type="text" name="PrimerApellido" id="PrimerApellido" class="form-control form-control-user" value="<?php echo e(isset($empleado->PrimerApellido)?$empleado->PrimerApellido:''); ?>" placeholder="[PRIMER APELLIDO]" required>

                    <div class="invalid-feedback">
                        Valid last name is required.
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="Correo" class="m-0 font-weight-bold text-primary"><?php echo e('Correo'); ?></label>
                    <input type="email" name="Correo" id="Correo" class="form-control form-control-user" value="<?php echo e(isset($empleado->Correo)?$empleado->Correo:''); ?>" placeholder="[CORREO]" required>
                    <div class="invalid-feedback">
                        Valid first name is required.
                    </div>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="Empresa" class="m-0 font-weight-bold text-primary"><?php echo e('Empresa'); ?></label>
                    <input type="text" name="Empresa" id="Empresa" class="form-control form-control-user" value="<?php echo e(isset($empleado->Empresa)?$empleado->Empresa:''); ?>" placeholder="[EMPRESA]" required>

                    <div class="invalid-feedback">
                        Valid last name is required.
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="Cargo" class="m-0 font-weight-bold text-primary"><?php echo e('Cargo'); ?></label>
                    <input type="text" name="Cargo" id="Cargo" class="form-control form-control-user" value="<?php echo e(isset($empleado->Cargo)?$empleado->Cargo:''); ?>" placeholder="[Cargo]" required>
                    <div class="invalid-feedback">
                        Valid first name is required.
                    </div>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="Salario" class="m-0 font-weight-bold text-primary"><?php echo e('Salario'); ?></label>
                    <input type="text" name="Salario" id="Salario" class="form-control form-control-user" value="<?php echo e(isset($empleado->Salario)?$empleado->Salario:''); ?>" placeholder="[Salario]" required>

                    <div class="invalid-feedback">
                        Valid last name is required.
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="Tcontrato" class="m-0 font-weight-bold text-primary"><?php echo e('Tcontrato'); ?></label>
                    <input type="text" name="Tcontrato" id="Tcontrato" class="form-control form-control-user" value="<?php echo e(isset($empleado->Tcontrato)?$empleado->Tcontrato:''); ?>" placeholder="[Tcontrato]" required>
                    <div class="invalid-feedback">
                        Valid first name is required.
                    </div>
                </div>
                    <?php if(Auth::user()->id < '3'): ?>
                <div class="col-md-6 mb-3">
                    <input type="file" class="custom-file-input" id="Foto" name="Foto">
                    <label class="custom-file-label" for="validatedCustomFile" placeholder="[FOTO]" required><?php echo e('Foto'); ?></label>
                    <div class="invalid-feedback">Example invalid custom file feedback</div>
                    <div class="invalid-feedback">
                        Valid last name is required.
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <hr class="mb-4">
    <?php if(Auth::user()->id < '3'): ?>
<input type="submit" class="btn btn-primary" value="<?php echo e($Modo=='crear' ? 'Agregar':'Modificar'); ?>">
  <a href="<?php echo e(url('empleados')); ?>" class="btn btn-primary">Regresar</a>
    <?php else: ?>
      <a href="<?php echo e(url('intro')); ?>" class="btn btn-primary">Regresar</a>
<?php endif; ?>


        </form>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\solucionesintranet\resources\views/empleados/form.blade.php ENDPATH**/ ?>